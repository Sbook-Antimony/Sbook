import os
from pathlib import Path
import shutil

from pyoload import *

from . import objects, assets
from note import *
__id__ = 0

C_P = Cast(Path)

@annotate
def gid(reset:bool=False):
    global __id__
    if reset:
        __id__ = 0
    else:
        __id__ += 1
    return __id__


@annotate
class Tag(list):
    
    def __init__(self:"Tag", _parent:"Tag", _name:str, _attrs:dict={}, **kw):
        self.name = _name
        self.attrs = {x[1:] if x[0]=='_' else x: y for x, y in (_attrs|kw).items()}


        self.child = _parent is not None
        if self.child:
            _parent.append(self)
        super().__init__()
        
    def render(self:"Tag", inchr:str):
        print("rendering", self.name, self.child)
        txt = f"<{self.name}"
        for a, v in self.attrs.items():
            txt += f' {a}="{v}"'
        txt +=">\n"

        for child in self:
            txt += child.render(inchr)
        txt += f"\n</{self.name}>"
        ret = ""
        if self.child:
            for ln in txt.splitlines():
                ret += inchr+ln+"\n"
            return ret
        return txt

@annotate
def clear(dir:Cast(Path)):
    if dir.is_dir():
        for x in dir.glob("*"):
            clear(x)
        dir.rmdir()
    else:
        dir.unlink()

@annotate
class TTag(Tag):
    parent:Tag
    text:str
    def __init__(self:Tag, parent:Tag, txt:str):
        parent.append(self)
        self.text = txt
    def render(self:Tag, inchr:str):
        return ("\n").join(inchr+ln for ln in self.text.splitlines())
        
@annotate
class OTag(Tag):
    def render(self:Tag, inchr:str):
        txt = inchr+f"<{self.name}"
        for a, v in self.attrs.items():
            txt += f' {a}="{v}"'
        txt +=" />\n"
        return txt
def load_xml(doc:objects.NoteDocument) -> Tag:
    root = Tag(None,"html", lang=doc.attrs.get('lang'))
    head = Tag(root, "head")
    OTag(head, "meta", charset="utf-8")
    OTag(head, "meta", name="viewport", content="width=device-width, initial-scale=1.0")
    OTag(head, "link", rel="stylesheet", href="assets/note.css")
    OTag(head, "link", rel="stylesheet", href="assets/w3.css")
    Tag   (head, "script", src='assets/note.js')
    Tag   (head, "script", src='assets/jquery.js')
    Tag   (head, "script", src='assets/angular.min.js')

    body = Tag(root, "body")
    recur_render(body, doc)
    return root.render('    ')

def recur_render(elt:Tag, doc:objects.NoteBase):
    print("recur_render:", elt, doc)
    match doc.__class__:
        case objects.NoteDocument:
            for child in doc.children:
                recur_render(elt, child)
                
        case objects.NoteTopic:
            TTag(Tag(section:=Tag(elt, "section",_class="note-NoteTopic"), "h1", id="topic:"+doc.meta_name), doc.name)
            for child in doc.children:
                recur_render(section, child)
        case objects.NoteDefinition:
            main = Tag(elt, "div", _class="note-NoteDefinition")
            TTag(Tag(main, "h4", id="definition:"+doc.meta_name), doc.name if hasattr(doc, 'name') else "definition")
            for child in doc.children:
                recur_render(main, child)
        case objects.NoteText:
            TTag(elt, doc.text)
        case objects.NoteMore:
            more = nMore(elt, doc.attrs)
            for child in doc.children:
                recur_render(more.container, child)
        case a:
            raise ValueError(a, doc)

def nMore(p:Tag, kw:dict[str, str]):
    main = Tag(
        p,
        'div',
        _class = "nMore"
    )
    btn = Tag(main, "button", onclick="""$(this)""")
    TTag(btn, kw.get("title", "more<hr>"))
    main.container = Tag(main, 'div')
    return main
def init_dir(_dir:Cast(Path)):
    if _dir.exists():
        clear(_dir)
    _dir.mkdir()
    shutil.copytree(assets.assets, _dir / "assets")

def dump_document(document:objects.NoteDocument, _dir:C_P):
    init_dir(_dir)
    index = _dir / "index.html"
    index.touch()
    index.write_text(load_xml(document))
