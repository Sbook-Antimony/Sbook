from pathlib import Path

noteDir = Path(__file__).parent
resourcesDir = noteDir/"resources"