import loader, dumper, sys
#format >notes compile raw bin

cmd = sys.argv[1]
if cmd == 'build':
    dumper.dump_document(loader.parse_notes(sys.argv[2])[0], sys.argv[3])
